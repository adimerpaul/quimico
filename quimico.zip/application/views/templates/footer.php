
</div>
</div>
</div>
<!-- /page content -->

<!-- footer content -->
<footer>
    <div class="pull-right">
        Gentelella - Bootstrap Admin Template by <a href="https://colorlib.com">Colorlib</a>
    </div>
    <div class="clearfix"></div>
</footer>
<!-- /footer content -->
</div>
</div>

<!-- jQuery -->
<script src="<?=base_url()?>vendors/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="<?=base_url()?>vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<!-- FastClick -->
<script src="<?=base_url()?>vendors/fastclick/lib/fastclick.js"></script>
<!-- NProgress -->
<script src="<?=base_url()?>vendors/nprogress/nprogress.js"></script>

<!-- Custom Theme Scripts -->
<script src="<?=base_url()?>build/js/custom.min.js"></script>
</body>
</html>
